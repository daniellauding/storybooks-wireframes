globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8bf06ede893191af.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/46555f69f67186d0.js",
    "static/chunks/turbopack-fe999cee6f6a8cf7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];