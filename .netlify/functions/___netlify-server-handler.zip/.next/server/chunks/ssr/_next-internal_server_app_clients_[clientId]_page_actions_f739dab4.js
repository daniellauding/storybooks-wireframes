module.exports=[65302,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_clients_%5BclientId%5D_page_actions_f739dab4.js.map