module.exports=[95636,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5BprojectId%5D_page_actions_18a2306e.js.map