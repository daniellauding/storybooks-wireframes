module.exports=[63263,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Bclient%5D_page_actions_02507c5e.js.map